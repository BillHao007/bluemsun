var swiperItem = document.getElementsByClassName('swiper-item');
var dot = document.getElementsByClassName('dot');
var swiperInterval;
var wheelCnt = 0;

window.onload = function(){
	var index = 1;
	last = 0;  /*全局变量，为了点击指示点更换swiper也能使用到last这个变量*/
	swiperInterval = setInterval(function(){
		swiperItem[index].style.opacity = "1";  /*下一个swiper显示*/
		dot[index].style.opacity = "1";   /*下一个指示点变量*/
		dot[last].style.opacity = "0.6";  //上一个指示点变暗
		swiperItem[last].style.opacity="0";  //上一个指示点变暗
		last = index;
		index++;
		if(index === 4) index = 0;
	},5000);
}

function changeSwiper(idx){
	clearInterval(swiperInterval);  //指示点被点击后，终止swiper自动播放
	if(idx === 4) idx = 0;
	if(idx != last)  //防止用户点击正在播放的页面
	{
		swiperItem[idx].style.opacity = "1";
		dot[idx].style.opacity = "1";
		dot[last].style.opacity = "0.6";
		swiperItem[last].style.opacity="0";
	}
	last = idx;
	idx++;
	swiperInterval = setInterval(function(){   //再次开启自动播放
		if(idx === 4) idx = 0;
		swiperItem[idx].style.opacity = "1";
		dot[idx].style.opacity = "1";
		dot[last].style.opacity = "0.6";
		swiperItem[last].style.opacity="0";
		last = idx;
		idx++;
	},5000);
}

 if(document.addEventListener){  //火狐浏览器监听鼠标滚轮事件
 	document.addEventListener('DOMMouseScroll',wheel,false);
 }

window.onmousewheel = document.onmousewheel = wheel;  //其余浏览器监听鼠标滚轮事件

/*此函数是为了让顶部导航栏在滚过轮播图后再将背景改为白色*/
function wheel(event){
	var clubName = document.getElementById('club-name');
	var navBar = document.getElementsByClassName('navigation-bar');
	var li = document.getElementsByTagName('li');
	var delta, base, bottom;
	if(event.wheelDelta !== undefined){
		delta = -event.wheelDelta;  //其他浏览器获取滚轮值
		base = 10;
		bottom = 46;
	}
	else{
		delta = event.detail;   //火狐浏览器获取滚轮值
		base = 4;
		bottom = 19;
	}
	if(delta < 0 && wheelCnt != 0) wheelCnt--;
	else if(delta > 0 && wheelCnt < bottom) wheelCnt++;

	if(wheelCnt >= base){
		navBar[0].style.background = "rgba(255,255,255,1)";
		navBar[0].style.boxShadow = "0 4px 8px rgba(7, 17, 27, 0.2)"
		clubName.style.color = "#000";
		for(var i = 1; i <= 3; i++)
			li[i].style.color = "#000";
	}
	else{
		navBar[0].style.background = "rgba(255,255,255,0)";
		navBar[0].style.boxShadow = "0 0 0 rgba(255, 255, 255, 0)"
		clubName.style.color = "#fff";
		for(var i = 1; i <= 3; i++)
			li[i].style.color = "rgba(255,255,255,0.8)";
	}
}